# Lecteur vocal (FR / EN / AR) avec enregistreur interne

Application Android qui lit un texte à voix haute en français, anglais et arabe
(détection automatique de la langue), en ignorant les caractères choisis (`*`, `#`, `_`, ponctuation, etc.),
et qui peut enregistrer ce même texte en **WAV** et/ou **MP3**.

## Fonctions

- Saisie, collage, import d'un fichier `.txt`, ou partage d'un texte vers l'application.
- Détection automatique de la langue par phrase (et par segment en cas de texte mélangé) ; choix manuel possible.
- Vitesse et hauteur réglables, Pause / Reprendre (reprise au début de la phrase en cours), Stop, phrase surlignée.
- Filtre de caractères (écran « Réglages ») :
  - symboles supprimés, cases à cocher ;
  - ponctuation remplacée par une pause (ou supprimée) ;
  - champ libre pour ajouter d'autres caractères ;
  - durée de la pause réglable.
- Enregistreur interne : le texte nettoyé est synthétisé directement vers un fichier (sans micro),
  puis exporté en WAV et/ou MP3. La lecture et l'enregistrement utilisent exactement le même texte filtré.
- Écran « Fichiers » : écouter, partager, exporter vers un dossier au choix, supprimer.

## Compiler l'APK avec GitHub (sans Android Studio)

1. Créer un dépôt (par exemple `lecteur-vocal`) sur le compte GitHub MahMoh1960.
2. Téléverser deux fichiers à la racine : `projet.zip` (sans l'extraire) et `build.yml`.
3. Ouvrir `build.yml` → crayon (modifier) → dans le nom du fichier, écrire `.github/workflows/build.yml` → *Commit*.
4. Onglet **Actions** → « Compiler l'APK » (il se lance au commit, ou bouton *Run workflow*).
5. Une fois terminé, ouvrir l'exécution et télécharger l'artefact **LecteurVocal-apk** : il contient `app-debug.apk`.
6. Installer l'APK sur le téléphone (autoriser les sources inconnues si demandé).

## Voix nécessaires

L'application utilise le moteur de synthèse vocale du téléphone (idéalement « Synthèse vocale Google »).
Pour un fonctionnement hors ligne, télécharger les voix **Français**, **Anglais** et **Arabe**
dans Réglages Android › Synthèse vocale.

## Remarques

- Les enregistrements sont stockés dans le dossier propre à l'application
  (`Android/data/ma.lecteurvocal/files/Music/Enregistrements`) ; le bouton **Exporter** permet de les copier ailleurs.
- L'encodeur MP3 (LAME) est récupéré via JitPack. S'il est indisponible sur l'appareil, l'application
  crée le WAV et l'indique.
