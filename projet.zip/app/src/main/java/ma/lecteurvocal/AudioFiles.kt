package ma.lecteurvocal

import com.naman14.androidlame.LameBuilder
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Lecture des WAV produits par le moteur vocal (PCM 16 bits). */
object WavReader {

    class Wav(val rate: Int, val pcm: ShortArray)

    fun read(file: File): Wav {
        val bytes = file.readBytes()
        if (bytes.size < 44) throw IOException("Fichier audio vide")
        if (String(bytes, 0, 4, Charsets.US_ASCII) != "RIFF") throw IOException("Format audio inattendu")
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        var pos = 12
        var rate = 0
        var channels = 1
        var bits = 16
        var fmtTag = 1
        var dataStart = -1
        var dataLen = 0
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4, Charsets.US_ASCII)
            val size = bb.getInt(pos + 4)
            val body = pos + 8
            if (id == "fmt " && body + 16 <= bytes.size) {
                fmtTag = bb.getShort(body).toInt() and 0xFFFF
                channels = bb.getShort(body + 2).toInt()
                rate = bb.getInt(body + 4)
                bits = bb.getShort(body + 14).toInt()
            } else if (id == "data") {
                dataStart = body
                dataLen = if (size <= 0 || body.toLong() + size > bytes.size) bytes.size - body else size
                break
            }
            if (size < 0) break
            pos = body + size + (size and 1)
        }
        if (dataStart < 0 || rate <= 0) throw IOException("En-tête audio invalide")
        if (bits != 16 || (fmtTag != 1 && fmtTag != 0xFFFE)) {
            throw IOException("Format audio non pris en charge ($bits bits)")
        }
        if (channels < 1) channels = 1

        val frames = dataLen / (2 * channels)
        val out = ShortArray(frames)
        for (f in 0 until frames) {
            var sum = 0
            for (c in 0 until channels) {
                sum += bb.getShort(dataStart + (f * channels + c) * 2).toInt()
            }
            out[f] = (sum / channels).toShort()
        }
        return Wav(rate, out)
    }
}

/** Fichier PCM brut (mono, 16 bits) dans lequel on accumule tous les segments. */
class PcmSink(cacheDir: File) {

    val file: File = File.createTempFile("rec_", ".pcm", cacheDir)
    private val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)

    var rate: Int = 0
        private set

    var samples: Long = 0
        private set

    fun addSpeech(w: WavReader.Wav) {
        if (rate == 0) rate = if (w.rate in MP3_RATES) w.rate else 22050
        val data = if (w.rate == rate) w.pcm else resample(w.pcm, w.rate, rate)
        write(data)
    }

    fun addSilence(ms: Int) {
        if (rate == 0 || ms <= 0) return
        write(ShortArray(rate * ms / 1000))
    }

    private fun write(a: ShortArray) {
        val buf = ByteBuffer.allocate(a.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        buf.asShortBuffer().put(a)
        out.write(buf.array())
        samples += a.size
    }

    fun close() {
        out.flush()
        out.close()
    }

    companion object {
        val MP3_RATES = setOf(8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000)

        fun resample(src: ShortArray, from: Int, to: Int): ShortArray {
            if (from == to || src.isEmpty()) return src
            val n = (src.size.toLong() * to / from).toInt()
            val out = ShortArray(n)
            val ratio = from.toDouble() / to
            for (i in 0 until n) {
                val pos = i * ratio
                val i0 = pos.toInt()
                val frac = pos - i0
                val a = src[minOf(i0, src.size - 1)].toInt()
                val b = src[minOf(i0 + 1, src.size - 1)].toInt()
                out[i] = (a + (b - a) * frac).toInt().toShort()
            }
            return out
        }
    }
}

/** Écriture des fichiers finaux à partir du PCM brut. */
object AudioWriter {

    fun writeWav(raw: File, rate: Int, samples: Long, dest: File) {
        val dataLen = samples * 2
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray(Charsets.US_ASCII))
        h.putInt((36 + dataLen).toInt())
        h.put("WAVE".toByteArray(Charsets.US_ASCII))
        h.put("fmt ".toByteArray(Charsets.US_ASCII))
        h.putInt(16)
        h.putShort(1.toShort())            // PCM
        h.putShort(1.toShort())            // mono
        h.putInt(rate)
        h.putInt(rate * 2)                 // octets par seconde
        h.putShort(2.toShort())            // alignement
        h.putShort(16.toShort())           // bits par échantillon
        h.put("data".toByteArray(Charsets.US_ASCII))
        h.putInt(dataLen.toInt())
        FileOutputStream(dest).use { os ->
            os.write(h.array())
            FileInputStream(raw).use { it.copyTo(os) }
        }
    }

    fun writeMp3(raw: File, rate: Int, dest: File) {
        val lame = LameBuilder()
            .setInSampleRate(rate)
            .setOutChannels(1)
            .setOutBitrate(96)
            .setOutSampleRate(rate)
            .build()
        try {
            FileOutputStream(dest).use { os ->
                val chunk = 8192
                val bytes = ByteArray(chunk * 2)
                val shorts = ShortArray(chunk)
                val mp3 = ByteArray((7200 + chunk * 1.25).toInt())
                FileInputStream(raw).use { ins ->
                    while (true) {
                        val n = readFully(ins, bytes)
                        if (n < 2) break
                        val count = n / 2
                        ByteBuffer.wrap(bytes, 0, n).order(ByteOrder.LITTLE_ENDIAN)
                            .asShortBuffer().get(shorts, 0, count)
                        val encoded = lame.encode(shorts, shorts, count, mp3)
                        if (encoded > 0) os.write(mp3, 0, encoded)
                        if (n < bytes.size) break
                    }
                }
                val tail = lame.flush(mp3)
                if (tail > 0) os.write(mp3, 0, tail)
            }
        } finally {
            lame.close()
        }
    }

    private fun readFully(ins: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val r = ins.read(buf, total, buf.size - total)
            if (r < 0) break
            total += r
        }
        return total
    }
}
