package ma.lecteurvocal

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * « Enregistreur interne » : fait synthétiser chaque segment directement vers un fichier
 * (sans passer par le micro), assemble le tout avec les pauses, puis écrit WAV et/ou MP3.
 */
class Exporter(private val ctx: Context, private val hub: TtsHub) {

    interface Listener {
        fun onProgress(done: Int, total: Int)
        fun onFinished(files: List<File>, note: String?)
        fun onError(msg: String)
    }

    var listener: Listener? = null

    var running: Boolean = false
        private set

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private var token = 0
    private var items: List<Item> = emptyList()
    private var index = 0
    private var awaiting = false
    private var skipped = 0
    private var sink: PcmSink? = null
    private var wantWav = true
    private var wantMp3 = true
    private var rate = 1.0f
    private var pitch = 1.0f
    private val seg = File(ctx.cacheDir, "segment.wav")
    private val missing = HashSet<Lang>()

    fun start(list: List<Item>, wav: Boolean, mp3: Boolean, rate: Float, pitch: Float) {
        if (running) return
        if (list.none { it is Item.Speech }) {
            listener?.onError("Aucun texte à enregistrer.")
            return
        }
        items = list
        index = 0
        skipped = 0
        awaiting = false
        wantWav = wav
        wantMp3 = mp3
        this.rate = rate
        this.pitch = pitch
        missing.clear()
        try {
            sink = PcmSink(ctx.cacheDir)
        } catch (e: IOException) {
            listener?.onError("Impossible de créer le fichier temporaire.")
            return
        }
        token++
        running = true
        hub.onUtteranceEnd = { id, ok -> onEnd(id, ok) }
        step()
    }

    fun cancel() {
        if (!running) return
        token++
        running = false
        awaiting = false
        hub.onUtteranceEnd = null
        try {
            hub.tts.stop()
        } catch (e: Exception) {
            // ignoré
        }
        val s = sink
        sink = null
        worker.execute {
            try {
                s?.close()
            } catch (e: Exception) {
                // ignoré
            }
            s?.file?.delete()
            seg.delete()
        }
    }

    private fun fail(msg: String) {
        cancel()
        listener?.onError(msg)
    }

    private fun step() {
        if (!running) return
        listener?.onProgress(index, items.size)
        if (index >= items.size) {
            finish()
            return
        }
        val t = token
        when (val item = items[index]) {
            is Item.Pause -> {
                val s = sink
                worker.execute {
                    try {
                        s?.addSilence(item.ms)
                    } catch (e: Exception) {
                        // ignoré
                    }
                    main.post {
                        if (t == token && running) {
                            index++
                            step()
                        }
                    }
                }
            }
            is Item.Speech -> {
                val tts = hub.tts
                val r = tts.setLanguage(item.lang.locale)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    missing.add(item.lang)
                    skipped++
                    index++
                    main.post { if (t == token && running) step() }
                    return
                }
                tts.setSpeechRate(rate)
                tts.setPitch(pitch)
                seg.delete()
                awaiting = true
                val res = tts.synthesizeToFile(item.text, Bundle(), seg, "x${token}_$index")
                if (res != TextToSpeech.SUCCESS) {
                    awaiting = false
                    fail("La synthèse vers un fichier a échoué.")
                }
            }
        }
    }

    private fun onEnd(id: String, ok: Boolean) {
        if (!running || !awaiting || !id.startsWith("x")) return
        val parts = id.substring(1).split("_")
        if (parts.size != 2) return
        if (parts[0].toIntOrNull() != token || parts[1].toIntOrNull() != index) return
        awaiting = false
        val t = token
        if (!ok) {
            skipped++
            index++
            step()
            return
        }
        val s = sink
        worker.execute {
            try {
                val wav = WavReader.read(seg)
                s?.addSpeech(wav)
                s?.addSilence(60)
                main.post {
                    if (t == token && running) {
                        index++
                        step()
                    }
                }
            } catch (e: Exception) {
                main.post {
                    if (t == token && running) fail(e.message ?: "Erreur audio")
                }
            }
        }
    }

    private fun finish() {
        val s = sink ?: return
        running = false
        hub.onUtteranceEnd = null
        val warn = missing.joinToString { it.label }
        worker.execute {
            val outFiles = ArrayList<File>()
            var note: String? = null
            try {
                s.close()
                if (s.samples == 0L) throw IOException("Aucun audio n'a été produit.")
                val base = "lecture_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val dir = Storage.dir(ctx)
                if (wantWav) {
                    val f = File(dir, "$base.wav")
                    AudioWriter.writeWav(s.file, s.rate, s.samples, f)
                    outFiles.add(f)
                }
                if (wantMp3) {
                    val f = File(dir, "$base.mp3")
                    try {
                        AudioWriter.writeMp3(s.file, s.rate, f)
                        outFiles.add(f)
                    } catch (e: Throwable) {
                        f.delete()
                        note = "MP3 indisponible sur cet appareil (" + (e.message ?: e.javaClass.simpleName) + ")."
                    }
                }
                if (outFiles.isEmpty()) {
                    val f = File(dir, "$base.wav")
                    AudioWriter.writeWav(s.file, s.rate, s.samples, f)
                    outFiles.add(f)
                    note = (note ?: "") + " Fichier WAV créé à la place."
                }
                if (warn.isNotEmpty()) {
                    note = (note ?: "") + " Voix manquante(s) ignorée(s) : " + warn + "."
                }
                if (skipped > 0 && warn.isEmpty()) {
                    note = (note ?: "") + " $skipped segment(s) non synthétisé(s)."
                }
                s.file.delete()
                seg.delete()
                val finalNote = note?.trim()
                main.post {
                    sink = null
                    listener?.onFinished(outFiles, finalNote)
                }
            } catch (e: Exception) {
                s.file.delete()
                main.post {
                    sink = null
                    listener?.onError(e.message ?: "Erreur lors de l'écriture des fichiers.")
                }
            }
        }
    }
}
