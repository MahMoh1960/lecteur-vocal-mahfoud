package ma.lecteurvocal

/**
 * Détection automatique de la langue (arabe / français / anglais).
 * - L'arabe est reconnu par son écriture.
 * - Français et anglais (même alphabet) sont départagés par des mots courants,
 *   des accents et quelques terminaisons caractéristiques.
 */
class LangDetector {

    data class Run(val lang: Lang, val text: String)

    private var lastLatin: Lang = Lang.FR
    private var lastAny: Lang = Lang.FR

    fun segment(text: String): List<Run> {
        // 1) découpage par écriture : 1 = arabe, 2 = latin, 0 = aucune lettre
        val parts = ArrayList<Pair<Int, String>>()
        var cur = 0
        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            val n = Character.charCount(cp)
            val script = when {
                isArabicLetter(cp) -> 1
                Character.isLetter(cp) -> 2
                else -> 0
            }
            if (script != 0 && cur != 0 && script != cur) {
                parts.add(Pair(cur, sb.toString()))
                sb.setLength(0)
            }
            if (script != 0) cur = script
            sb.appendCodePoint(cp)
            i += n
        }
        if (sb.isNotEmpty()) parts.add(Pair(cur, sb.toString()))

        // 2) langue de chaque morceau
        val runs = ArrayList<Run>()
        for (part in parts) {
            val script = part.first
            val str = part.second.trim()
            if (str.isEmpty()) continue
            val lang = when (script) {
                1 -> Lang.AR
                2 -> classifyLatin(str) ?: lastLatin
                else -> lastAny
            }
            if (script == 2) lastLatin = lang
            lastAny = lang
            runs.add(Run(lang, str))
        }

        // 3) fusion des morceaux consécutifs de même langue
        val merged = ArrayList<Run>()
        for (r in runs) {
            val last = merged.lastOrNull()
            if (last != null && last.lang == r.lang) {
                merged[merged.size - 1] = Run(r.lang, last.text + " " + r.text)
            } else {
                merged.add(r)
            }
        }
        return merged
    }

    companion object {
        private val FR_WORDS = setOf(
            "le", "la", "les", "des", "une", "un", "du", "de", "au", "aux", "et", "est", "sont",
            "pas", "que", "qui", "pour", "dans", "sur", "avec", "nous", "vous", "ce", "cette",
            "ces", "je", "il", "elle", "ils", "elles", "mais", "ou", "où", "ne", "se", "ses",
            "leur", "leurs", "mon", "mes", "notre", "votre", "vos", "nos", "par", "très", "être",
            "avoir", "fait", "comme", "aussi", "tout", "tous", "cela", "ça", "en", "sans", "chez",
            "donc", "ainsi", "bonjour", "merci", "salut", "oui", "l", "d", "qu", "j"
        )

        private val EN_WORDS = setOf(
            "the", "of", "and", "to", "in", "is", "are", "was", "were", "be", "been", "that",
            "this", "with", "for", "it", "you", "he", "she", "they", "we", "not", "at", "by",
            "from", "have", "has", "had", "will", "would", "can", "could", "do", "does", "did",
            "which", "their", "there", "what", "when", "who", "his", "her", "its", "our", "your",
            "my", "them", "these", "those", "into", "than", "then", "also", "about", "more",
            "other", "some", "such", "only", "over", "just", "like", "hello", "hi", "yes",
            "please", "thanks", "thank", "i", "am", "if", "so", "all", "any", "how", "why", "where"
        )

        private val TOKEN_SPLIT = Regex("[^\\p{L}]+")
        private val FR_ACCENTS = Regex("[àâäçéèêëîïôöùûüÿœæ]")

        fun isArabicLetter(cp: Int): Boolean {
            val inBlock = cp in 0x0600..0x06FF || cp in 0x0750..0x077F ||
                cp in 0x08A0..0x08FF || cp in 0xFB50..0xFDFF || cp in 0xFE70..0xFEFF
            return inBlock && Character.isLetter(cp)
        }

        /** Renvoie FR ou EN, ou null si le texte ne permet pas de trancher. */
        fun classifyLatin(text: String): Lang? {
            var fr = 0.0
            var en = 0.0
            for (t in TOKEN_SPLIT.split(text.lowercase())) {
                if (t.isEmpty()) continue
                if (t in FR_WORDS) fr += 1.0
                if (t in EN_WORDS) en += 1.0
                if (FR_ACCENTS.containsMatchIn(t)) fr += 2.0
                if (t.contains("w")) en += 0.4
                if (t.contains("th")) en += 0.5
                if (t.contains("ck")) en += 0.4
                if (t.length > 4 && t.endsWith("ing")) en += 0.5
                if (t.contains("eau")) fr += 0.5
                if (t.length > 4 && t.endsWith("ment")) fr += 0.4
                if (t.length > 3 && t.endsWith("ez")) fr += 0.3
            }
            return when {
                fr - en > 0.25 -> Lang.FR
                en - fr > 0.25 -> Lang.EN
                else -> null
            }
        }
    }
}
