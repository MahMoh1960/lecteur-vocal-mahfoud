package ma.lecteurvocal

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale

class MainActivity : AppCompatActivity(), Player.Listener, Exporter.Listener {

    private lateinit var prefs: Prefs
    private lateinit var hub: TtsHub
    private lateinit var player: Player
    private lateinit var exporter: Exporter

    private lateinit var input: EditText
    private lateinit var spinLang: Spinner
    private lateinit var spinGender: Spinner
    private lateinit var labelRate: TextView
    private lateinit var labelPitch: TextView
    private lateinit var seekRate: SeekBar
    private lateinit var seekPitch: SeekBar
    private lateinit var btnPlay: Button
    private lateinit var btnPause: Button
    private lateinit var btnStop: Button
    private lateinit var btnRecord: Button
    private lateinit var chkWav: CheckBox
    private lateinit var chkMp3: CheckBox
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var highlightSpan: Any? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        input = findViewById(R.id.input)
        spinLang = findViewById(R.id.spinLang)
        spinGender = findViewById(R.id.spinGender)
        labelRate = findViewById(R.id.labelRate)
        labelPitch = findViewById(R.id.labelPitch)
        seekRate = findViewById(R.id.seekRate)
        seekPitch = findViewById(R.id.seekPitch)
        btnPlay = findViewById(R.id.btnPlay)
        btnPause = findViewById(R.id.btnPause)
        btnStop = findViewById(R.id.btnStop)
        btnRecord = findViewById(R.id.btnRecord)
        chkWav = findViewById(R.id.chkWav)
        chkMp3 = findViewById(R.id.chkMp3)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        hub = TtsHub(this, prefs) { ok -> onTtsReady(ok) }
        player = Player(hub)
        player.listener = this
        exporter = Exporter(this, hub)
        exporter.listener = this

        setupControls()
        handleIncoming(intent)
        refreshUi()
    }

    private fun setupControls() {
        val choices = arrayOf("Langue : détection automatique", "Français", "English", "العربية")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, choices)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinLang.adapter = adapter
        spinLang.setSelection(prefs.langChoice)
        spinLang.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.langChoice = position
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val genders = arrayOf("Voix féminine", "Voix masculine")
        val genderAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genders)
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinGender.adapter = genderAdapter
        spinGender.setSelection(prefs.gender)
        spinGender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.gender = position
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        seekRate.progress = prefs.ratePos
        seekPitch.progress = prefs.pitchPos
        updateLabels()
        val seekListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                if (seekBar === seekRate) prefs.ratePos = value else prefs.pitchPos = value
                updateLabels()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        seekRate.setOnSeekBarChangeListener(seekListener)
        seekPitch.setOnSeekBarChangeListener(seekListener)

        chkWav.isChecked = prefs.fmtWav
        chkMp3.isChecked = prefs.fmtMp3
        chkWav.setOnCheckedChangeListener { _, checked -> prefs.fmtWav = checked }
        chkMp3.setOnCheckedChangeListener { _, checked -> prefs.fmtMp3 = checked }

        findViewById<Button>(R.id.btnImport).setOnClickListener { openTextFile() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (exporter.running) {
                toast("Enregistrement en cours : annulez-le d'abord.")
            } else {
                player.stop()
                highlightSpan = null
                input.setText("")
                status.text = "Texte effacé."
            }
        }
        findViewById<Button>(R.id.btnFiles).setOnClickListener {
            startActivity(Intent(this, RecordingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btnPlay.setOnClickListener { onPlay() }
        btnPause.setOnClickListener { onPauseResume() }
        btnStop.setOnClickListener { player.stop() }
        btnRecord.setOnClickListener { onRecord() }
    }

    // ------------------------------------------------------------------ réglages audio

    private fun rateValue(): Float = 0.5f + seekRate.progress / 100f
    private fun pitchValue(): Float = 0.5f + seekPitch.progress / 100f

    private fun updateLabels() {
        labelRate.text = String.format(Locale.FRANCE, "Vitesse : %.2f×", rateValue())
        labelPitch.text = String.format(Locale.FRANCE, "Hauteur : %.2f", pitchValue())
    }

    private fun forcedLang(): Lang? = when (spinLang.selectedItemPosition) {
        1 -> Lang.FR
        2 -> Lang.EN
        3 -> Lang.AR
        else -> null
    }

    private fun buildItems(): List<Item> =
        TextPipeline.build(input.text.toString(), prefs.filterConfig(), forcedLang())

    // ------------------------------------------------------------------ actions

    private fun onPlay() {
        if (!hub.ready) {
            toast("La synthèse vocale n'est pas prête.")
            return
        }
        if (exporter.running) return
        if (player.state == Player.State.PAUSED) {
            player.resume()
            return
        }
        player.rate = rateValue()
        player.pitch = pitchValue()
        player.start(buildItems())
    }

    private fun onPauseResume() {
        when (player.state) {
            Player.State.PLAYING -> player.pause()
            Player.State.PAUSED -> player.resume()
            else -> {}
        }
    }

    private fun onRecord() {
        if (exporter.running) {
            exporter.cancel()
            status.text = "Enregistrement annulé."
            refreshUi()
            return
        }
        if (!hub.ready) {
            toast("La synthèse vocale n'est pas prête.")
            return
        }
        if (!chkWav.isChecked && !chkMp3.isChecked) {
            toast("Cochez WAV et/ou MP3.")
            return
        }
        player.stop()
        val items = buildItems()
        status.text = "Enregistrement en cours…"
        exporter.start(items, chkWav.isChecked, chkMp3.isChecked, rateValue(), pitchValue())
        refreshUi()
    }

    // ------------------------------------------------------------------ interface

    private fun refreshUi() {
        val recording = exporter.running
        val state = player.state
        btnPlay.isEnabled = !recording && state != Player.State.PLAYING
        btnPause.isEnabled = !recording && state != Player.State.IDLE
        btnPause.text = if (state == Player.State.PAUSED) "▶ Reprendre" else "⏸ Pause"
        btnStop.isEnabled = !recording && state != Player.State.IDLE
        btnRecord.text = if (recording) "✖ Annuler" else "⏺ Enregistrer"
        btnRecord.isEnabled = recording || state == Player.State.IDLE
        progress.visibility = if (recording) View.VISIBLE else View.GONE

        if (recording || state == Player.State.PLAYING) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun highlight(start: Int, end: Int) {
        val ed = input.text
        highlightSpan?.let { ed.removeSpan(it) }
        highlightSpan = null
        if (start < 0 || end <= start || end > ed.length) return
        val span = BackgroundColorSpan(Color.argb(110, 255, 193, 7))
        ed.setSpan(span, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        highlightSpan = span
        try {
            input.bringPointIntoView(start)
        } catch (e: Exception) {
            // ignoré
        }
    }

    private fun onTtsReady(ok: Boolean) {
        if (!ok) {
            status.text = "Aucun moteur de synthèse vocale n'a pu démarrer. Installez « Synthèse vocale Google »."
            return
        }
        val missing = Lang.values()
            .filter { hub.tts.isLanguageAvailable(it.locale) < TextToSpeech.LANG_AVAILABLE }
            .map { it.label }
        status.text = if (missing.isEmpty()) {
            "Prêt."
        } else {
            "Voix manquante : " + missing.joinToString() +
                " — à installer dans Réglages › Synthèse vocale."
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ Player.Listener

    override fun onSpeak(start: Int, end: Int) {
        highlight(start, end)
    }

    override fun onState(state: Player.State) {
        if (state == Player.State.PLAYING) status.text = "Lecture…"
        if (state == Player.State.PAUSED) status.text = "En pause."
        if (state == Player.State.IDLE && !exporter.running) {
            if (status.text == "Lecture…" || status.text == "En pause.") status.text = "Prêt."
        }
        refreshUi()
    }

    override fun onNote(msg: String) {
        status.text = msg
    }

    // ------------------------------------------------------------------ Exporter.Listener

    override fun onProgress(done: Int, total: Int) {
        progress.max = if (total > 0) total else 1
        progress.progress = done
        refreshUi()
    }

    override fun onFinished(files: List<File>, note: String?) {
        refreshUi()
        val names = files.joinToString("\n") { "• " + it.name }
        status.text = "Enregistrement terminé."
        val message = names + (if (note.isNullOrEmpty()) "" else "\n\n$note")
        AlertDialog.Builder(this)
            .setTitle("Enregistrement terminé")
            .setMessage(message)
            .setPositiveButton("Voir les fichiers") { _, _ ->
                startActivity(Intent(this, RecordingsActivity::class.java))
            }
            .setNegativeButton("OK", null)
            .show()
    }

    override fun onError(msg: String) {
        status.text = "Erreur : $msg"
        refreshUi()
    }

    // ------------------------------------------------------------------ import / partage entrant

    @Suppress("DEPRECATION")
    private fun openTextFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/*"
        startActivityForResult(i, REQ_OPEN)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_OPEN || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            input.setText(decode(bytes))
            status.text = "Fichier importé."
        } catch (e: Exception) {
            toast("Lecture du fichier impossible.")
        }
    }

    private fun decode(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) {
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        }
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) {
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        }
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) {
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b))
                .toString()
        } catch (e: CharacterCodingException) {
            String(b, Charset.forName("windows-1252"))
        }
    }

    private fun handleIncoming(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            i.getStringExtra(Intent.EXTRA_TEXT)?.let { input.setText(it) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        player.stop()
        exporter.cancel()
        hub.shutdown()
    }

    companion object {
        private const val REQ_OPEN = 101
    }
}
