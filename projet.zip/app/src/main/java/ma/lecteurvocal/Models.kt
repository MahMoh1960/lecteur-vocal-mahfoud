package ma.lecteurvocal

import android.content.Context
import java.util.Locale

enum class Lang(val locale: Locale, val label: String) {
    FR(Locale.FRENCH, "Français"),
    EN(Locale.ENGLISH, "English"),
    AR(Locale("ar"), "العربية")
}

/** Élément de la file de lecture : un segment à prononcer ou un silence. */
sealed class Item {
    data class Speech(val text: String, val lang: Lang, val srcStart: Int, val srcEnd: Int) : Item()
    data class Pause(val ms: Int) : Item()
}

enum class PunctMode { PAUSE, REMOVE }

data class FilterConfig(
    val symbolsOff: Set<Int>,
    val punctOff: Set<Int>,
    val punctMode: PunctMode,
    val pauseMs: Int
)

object Defaults {
    const val SYMBOL_CANDIDATES = "*#_~^|\\/<>[]{}=+•·●◦▪■★→()\"«»“”‘’'`-–—@&%\$"
    const val SYMBOLS_ON = "*#_~^|\\/<>[]{}•·●◦▪■★→()\"«»“”‘’'`-–—"
    const val PUNCT_CANDIDATES = ".,;:!?…،؛؟"
    const val PUNCT_ON = ".,;:!?…،؛؟"
    const val PAUSE_MS = 600
}

fun String.toCodePointList(): List<Int> {
    val out = ArrayList<Int>()
    var i = 0
    while (i < length) {
        val cp = codePointAt(i)
        out.add(cp)
        i += Character.charCount(cp)
    }
    return out
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("lecteur_vocal", Context.MODE_PRIVATE)

    var symbolsOn: String
        get() = sp.getString("symbols", Defaults.SYMBOLS_ON) ?: Defaults.SYMBOLS_ON
        set(v) { sp.edit().putString("symbols", v).apply() }

    var punctOn: String
        get() = sp.getString("punct", Defaults.PUNCT_ON) ?: Defaults.PUNCT_ON
        set(v) { sp.edit().putString("punct", v).apply() }

    var extra: String
        get() = sp.getString("extra", "") ?: ""
        set(v) { sp.edit().putString("extra", v).apply() }

    var punctMode: PunctMode
        get() = if (sp.getString("mode", "pause") == "remove") PunctMode.REMOVE else PunctMode.PAUSE
        set(v) { sp.edit().putString("mode", if (v == PunctMode.REMOVE) "remove" else "pause").apply() }

    var pauseMs: Int
        get() = sp.getInt("pauseMs", Defaults.PAUSE_MS)
        set(v) { sp.edit().putInt("pauseMs", v).apply() }

    var ratePos: Int
        get() = sp.getInt("ratePos", 50)
        set(v) { sp.edit().putInt("ratePos", v).apply() }

    var pitchPos: Int
        get() = sp.getInt("pitchPos", 50)
        set(v) { sp.edit().putInt("pitchPos", v).apply() }

    var langChoice: Int
        get() = sp.getInt("langChoice", 0)
        set(v) { sp.edit().putInt("langChoice", v).apply() }

    var fmtWav: Boolean
        get() = sp.getBoolean("fmtWav", true)
        set(v) { sp.edit().putBoolean("fmtWav", v).apply() }

    var fmtMp3: Boolean
        get() = sp.getBoolean("fmtMp3", true)
        set(v) { sp.edit().putBoolean("fmtMp3", v).apply() }

    fun filterConfig(): FilterConfig = FilterConfig(
        symbolsOff = (symbolsOn + extra).toCodePointList().toSet(),
        punctOff = punctOn.toCodePointList().toSet(),
        punctMode = punctMode,
        pauseMs = pauseMs
    )

    fun resetFilters() {
        sp.edit()
            .remove("symbols").remove("punct").remove("extra")
            .remove("mode").remove("pauseMs")
            .apply()
    }
}
