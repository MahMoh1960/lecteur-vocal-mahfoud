package ma.lecteurvocal

import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech

/**
 * Lecture séquentielle : une phrase à la fois, la langue étant réglée avant chaque segment.
 * « Pause » arrête la phrase en cours ; « Reprendre » la relit depuis son début.
 */
class Player(private val hub: TtsHub) {

    enum class State { IDLE, PLAYING, PAUSED }

    interface Listener {
        fun onSpeak(start: Int, end: Int)
        fun onState(state: State)
        fun onNote(msg: String)
    }

    var listener: Listener? = null
    var rate: Float = 1.0f
    var pitch: Float = 1.0f

    var state: State = State.IDLE
        private set

    private val handler = Handler(Looper.getMainLooper())
    private var items: List<Item> = emptyList()
    private var index = 0
    private var token = 0
    private val warned = HashSet<Lang>()

    fun start(list: List<Item>) {
        halt()
        if (list.isEmpty()) {
            listener?.onNote("Aucun texte à lire.")
            return
        }
        items = list
        index = 0
        warned.clear()
        hub.onUtteranceEnd = { id, _ -> onEnd(id) }
        setState(State.PLAYING)
        step()
    }

    fun pause() {
        if (state != State.PLAYING) return
        token++
        handler.removeCallbacksAndMessages(null)
        hub.tts.stop()
        setState(State.PAUSED)
    }

    fun resume() {
        if (state != State.PAUSED) return
        token++
        setState(State.PLAYING)
        step()
    }

    fun stop() {
        halt()
        listener?.onSpeak(-1, -1)
    }

    private fun halt() {
        token++
        handler.removeCallbacksAndMessages(null)
        if (state != State.IDLE) hub.tts.stop()
        index = 0
        hub.onUtteranceEnd = null
        setState(State.IDLE)
    }

    private fun setState(s: State) {
        state = s
        listener?.onState(s)
    }

    private fun step() {
        if (state != State.PLAYING) return
        if (index >= items.size) {
            finish()
            return
        }
        when (val item = items[index]) {
            is Item.Pause -> {
                val t = token
                handler.postDelayed({
                    if (t == token && state == State.PLAYING) {
                        index++
                        step()
                    }
                }, item.ms.toLong())
            }
            is Item.Speech -> speak(item)
        }
    }

    private fun speak(sp: Item.Speech) {
        val tts = hub.tts
        val r = tts.setLanguage(sp.lang.locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (warned.add(sp.lang)) {
                listener?.onNote("Voix « ${sp.lang.label} » indisponible : installez-la dans les réglages de synthèse vocale.")
            }
            index++
            val t = token
            handler.post { if (t == token) step() }
            return
        }
        tts.setSpeechRate(rate)
        tts.setPitch(pitch)
        listener?.onSpeak(sp.srcStart, sp.srcEnd)
        val res = tts.speak(sp.text, TextToSpeech.QUEUE_FLUSH, null, "p${token}_$index")
        if (res == TextToSpeech.ERROR) {
            listener?.onNote("Erreur de synthèse vocale.")
            stop()
        }
    }

    private fun onEnd(id: String) {
        if (!id.startsWith("p") || state != State.PLAYING) return
        val parts = id.substring(1).split("_")
        if (parts.size != 2) return
        if (parts[0].toIntOrNull() != token || parts[1].toIntOrNull() != index) return
        index++
        step()
    }

    private fun finish() {
        index = 0
        hub.onUtteranceEnd = null
        setState(State.IDLE)
        listener?.onSpeak(-1, -1)
    }
}
