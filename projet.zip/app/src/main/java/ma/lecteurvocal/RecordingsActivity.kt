package ma.lecteurvocal

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Date

class RecordingsActivity : AppCompatActivity() {

    private var files: List<File> = emptyList()
    private var player: MediaPlayer? = null
    private var playing: File? = null
    private var pendingExport: File? = null

    private lateinit var list: ListView
    private lateinit var empty: TextView

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = files.size
        override fun getItem(position: Int): Any = files[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: LayoutInflater.from(this@RecordingsActivity)
                .inflate(R.layout.row_recording, parent, false)
            val f = files[position]
            v.findViewById<TextView>(R.id.rowName).text = f.name
            val size = Formatter.formatShortFileSize(this@RecordingsActivity, f.length())
            val date = DateFormat.format("dd/MM/yyyy HH:mm", Date(f.lastModified()))
            v.findViewById<TextView>(R.id.rowInfo).text = "$size · $date"
            val play = v.findViewById<Button>(R.id.rowPlay)
            play.text = if (playing == f) "Arrêter" else "Lire"
            play.setOnClickListener { togglePlay(f) }
            v.findViewById<Button>(R.id.rowShare).setOnClickListener { share(f) }
            v.findViewById<Button>(R.id.rowExport).setOnClickListener { export(f) }
            v.findViewById<Button>(R.id.rowDelete).setOnClickListener { confirmDelete(f) }
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recordings)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        list.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    override fun onPause() {
        super.onPause()
        stopPlay()
    }

    private fun reload() {
        files = Storage.list(this)
        empty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun togglePlay(f: File) {
        val wasPlaying = playing == f
        stopPlay()
        if (wasPlaying) return
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { stopPlay() }
            mp.prepare()
            mp.start()
            player = mp
            playing = f
            adapter.notifyDataSetChanged()
        } catch (e: Exception) {
            Toast.makeText(this, "Lecture impossible.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopPlay() {
        val mp = player
        player = null
        playing = null
        if (mp != null) {
            try {
                mp.stop()
            } catch (e: Exception) {
                // ignoré
            }
            mp.release()
        }
        adapter.notifyDataSetChanged()
    }

    private fun share(f: File) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = Storage.mime(f)
        i.putExtra(Intent.EXTRA_STREAM, Storage.uri(this, f))
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Partager l'enregistrement"))
    }

    @Suppress("DEPRECATION")
    private fun export(f: File) {
        pendingExport = f
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = Storage.mime(f)
        i.putExtra(Intent.EXTRA_TITLE, f.name)
        startActivityForResult(i, REQ_EXPORT)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_EXPORT || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val src = pendingExport ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                src.inputStream().use { it.copyTo(out) }
            }
            Toast.makeText(this, "Fichier exporté.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export impossible.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete(f: File) {
        AlertDialog.Builder(this)
            .setTitle("Supprimer ?")
            .setMessage(f.name)
            .setPositiveButton("Supprimer") { _, _ ->
                if (playing == f) stopPlay()
                f.delete()
                reload()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    companion object {
        private const val REQ_EXPORT = 202
    }
}
