package ma.lecteurvocal

import android.graphics.Typeface
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Réglages : caractères à ne pas lire et voix. Chaque modification est enregistrée aussitôt. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var hub: TtsHub
    private lateinit var voiceBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        build()
        hub = TtsHub(this, prefs) { ok -> fillVoices(ok) }
    }

    override fun onDestroy() {
        super.onDestroy()
        hub.shutdown()
    }

    // ------------------------------------------------------------------ voix

    private fun fillVoices(ok: Boolean) {
        voiceBox.removeAllViews()
        if (!ok) {
            voiceBox.addView(label("Moteur de synthèse vocale indisponible.", 12f, false))
            return
        }
        for (lang in Lang.values()) {
            voiceBox.addView(label(lang.label, 14f, true))
            val voices = hub.voicesFor(lang)
            if (voices.isEmpty()) {
                voiceBox.addView(
                    label("Aucune voix installée : à télécharger dans Réglages Android › Synthèse vocale.", 12f, false)
                )
                continue
            }
            val names = ArrayList<String>()
            val labels = ArrayList<String>()
            names.add("")
            labels.add("Voix par défaut")
            for ((i, v) in voices.withIndex()) {
                names.add(v.name)
                labels.add(voiceLabel(i + 1, v))
            }
            for (gender in 0..1) {
                voiceBox.addView(voiceRow(lang, gender, names, labels))
            }
        }
    }

    private fun voiceLabel(n: Int, v: Voice): String {
        val code = v.name.substringAfter("-x-", "").substringBefore("-")
        val net = if (v.isNetworkConnectionRequired) "en ligne" else "hors ligne"
        val codePart = if (code.isNotEmpty()) " ($code)" else ""
        return "Voix $n$codePart · " + v.locale.toLanguageTag() + " · " + net
    }

    private fun voiceRow(lang: Lang, gender: Int, names: List<String>, labels: List<String>): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.addView(label(if (gender == 0) "Voix féminine" else "Voix masculine", 12f, false))

        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spinner.setSelection(maxOf(0, names.indexOf(prefs.voiceFor(lang, gender))))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.setVoiceFor(lang, gender, names[position])
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        line.addView(spinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val listen = Button(this)
        listen.text = "Écouter"
        listen.setOnClickListener { test(lang, names[spinner.selectedItemPosition]) }
        line.addView(listen)

        row.addView(line)
        return row
    }

    private fun test(lang: Lang, voiceName: String) {
        if (!hub.ready) return
        hub.tts.stop()
        if (!hub.prepareWith(lang, voiceName)) {
            Toast.makeText(this, "Voix « " + lang.label + " » indisponible.", Toast.LENGTH_SHORT).show()
            return
        }
        val text = when (lang) {
            Lang.FR -> "Bonjour, ceci est un essai de la voix sélectionnée."
            Lang.EN -> "Hello, this is a test of the selected voice."
            Lang.AR -> "مرحبا، هذا اختبار للصوت المحدد."
        }
        hub.tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun label(text: String, size: Float, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = size
        if (bold) tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, dp(12), 0, dp(4))
        return tv
    }

    private fun build() {
        val root = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(32))
        root.addView(col)

        col.addView(label("Caractères à ne pas lire", 20f, true))
        col.addView(label("Les caractères cochés ne sont jamais prononcés.", 13f, false))

        col.addView(label("Symboles (supprimés)", 15f, true))
        col.addView(grid(Defaults.SYMBOL_CANDIDATES, prefs.symbolsOn) { prefs.symbolsOn = it })

        col.addView(label("Ponctuation", 15f, true))
        col.addView(grid(Defaults.PUNCT_CANDIDATES, prefs.punctOn) { prefs.punctOn = it })

        val group = RadioGroup(this)
        val rbPause = RadioButton(this)
        rbPause.id = 1001
        rbPause.text = "Remplacer par une pause (recommandé)"
        val rbRemove = RadioButton(this)
        rbRemove.id = 1002
        rbRemove.text = "Supprimer, sans pause"
        group.addView(rbPause)
        group.addView(rbRemove)
        group.check(if (prefs.punctMode == PunctMode.REMOVE) 1002 else 1001)
        group.setOnCheckedChangeListener { _, checkedId ->
            prefs.punctMode = if (checkedId == 1002) PunctMode.REMOVE else PunctMode.PAUSE
        }
        col.addView(group)
        col.addView(label("En mode pause, « ? » et « ! » gardent l'intonation de la phrase sans être prononcés.", 12f, false))

        col.addView(label("Autres caractères à ignorer", 15f, true))
        val extra = EditText(this)
        extra.setText(prefs.extra)
        extra.hint = "Tapez ici d'autres caractères, ex. ♪ ¤ §"
        extra.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                prefs.extra = s?.toString() ?: ""
            }
        })
        col.addView(extra)

        val pauseLabel = label("", 15f, true)
        col.addView(pauseLabel)
        val pauseSeek = SeekBar(this)
        pauseSeek.max = 1300
        pauseSeek.progress = prefs.pauseMs - 200
        pauseLabel.text = "Pause en fin de phrase : ${prefs.pauseMs} ms"
        pauseSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                val ms = value + 200
                prefs.pauseMs = ms
                pauseLabel.text = "Pause en fin de phrase : $ms ms"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(pauseSeek)

        col.addView(label("Voix", 20f, true))
        col.addView(
            label(
                "Android ne précise pas le genre des voix : écoutez-les, puis rangez chacune sous " +
                    "« féminine » ou « masculine ». Le choix se fait ensuite sur l'écran principal. " +
                    "Pour avoir plus de voix, téléchargez-les dans Réglages Android › Synthèse vocale.",
                12f,
                false
            )
        )
        voiceBox = LinearLayout(this)
        voiceBox.orientation = LinearLayout.VERTICAL
        voiceBox.addView(label("Chargement des voix…", 12f, false))
        col.addView(voiceBox)

        val reset = Button(this)
        reset.text = "Rétablir les valeurs par défaut"
        reset.setOnClickListener {
            prefs.resetFilters()
            recreate()
        }
        col.addView(reset)

        setContentView(root)
    }

    /** Grille de cases à cocher, une par caractère. onChange reçoit la chaîne des caractères cochés. */
    private fun grid(candidates: String, selected: String, onChange: (String) -> Unit): GridLayout {
        val g = GridLayout(this)
        g.columnCount = 5
        val chars = candidates.toCodePointList()
        val on = selected.toCodePointList().toSet()
        val boxes = ArrayList<Pair<Int, CheckBox>>()

        fun collect(): String {
            val sb = StringBuilder()
            for (p in boxes) {
                if (p.second.isChecked) sb.appendCodePoint(p.first)
            }
            return sb.toString()
        }

        for (cp in chars) {
            val cb = CheckBox(this)
            cb.text = String(Character.toChars(cp))
            cb.textSize = 18f
            cb.typeface = Typeface.MONOSPACE
            cb.isChecked = cp in on
            cb.setOnCheckedChangeListener { _, _ -> onChange(collect()) }
            boxes.add(Pair(cp, cb))
            g.addView(cb)
        }
        return g
    }
}
