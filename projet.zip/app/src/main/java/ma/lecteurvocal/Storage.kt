package ma.lecteurvocal

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File

object Storage {

    /** Dossier des enregistrements (propre à l'application, aucune permission requise). */
    fun dir(ctx: Context): File {
        val base = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
        val d = File(base, "Enregistrements")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun list(ctx: Context): List<File> {
        val all = dir(ctx).listFiles() ?: return emptyList()
        return all
            .filter { it.isFile && (it.extension.equals("wav", true) || it.extension.equals("mp3", true)) }
            .sortedByDescending { it.lastModified() }
    }

    fun uri(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

    fun mime(f: File): String =
        if (f.extension.equals("mp3", true)) "audio/mpeg" else "audio/x-wav"
}
