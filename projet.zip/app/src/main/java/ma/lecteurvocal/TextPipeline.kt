package ma.lecteurvocal

/**
 * Transforme le texte saisi en une liste d'éléments (segments à lire + pauses).
 * Le même résultat sert à la lecture ET à l'enregistrement : les deux disent donc
 * exactement la même chose.
 */
object TextPipeline {

    private val ABBREVIATIONS = setOf("mr", "mrs", "ms", "dr", "pr", "prof", "mme", "mlle", "mm", "st", "vs", "cf", "m")

    /** kind : 0 = fin du texte, 1 = ponctuation, 2 = retour à la ligne, 3 = paragraphe */
    private class Sent(val start: Int, val end: Int, val kind: Int, val term: Char)

    fun build(text: String, cfg: FilterConfig, forced: Lang?): List<Item> {
        val items = ArrayList<Item>()
        val detector = LangDetector()
        for (s in split(text)) {
            val raw = text.substring(s.start, s.end)
            val cleaned = clean(raw, cfg)
            if (cleaned.none { it.isLetterOrDigit() }) continue

            val runs: List<LangDetector.Run> =
                if (forced != null) listOf(LangDetector.Run(forced, cleaned)) else detector.segment(cleaned)
            for (r in runs) {
                for (chunk in chunk(r.text)) {
                    items.add(Item.Speech(chunk, r.lang, s.start, s.end))
                }
            }

            if (cfg.punctMode == PunctMode.PAUSE) {
                val ms = when (s.kind) {
                    3 -> cfg.pauseMs * 3 / 2
                    2 -> cfg.pauseMs * 4 / 5
                    1 -> if (cfg.punctOff.contains(s.term.code)) cfg.pauseMs else 0
                    else -> 0
                }
                if (ms > 0) items.add(Item.Pause(ms))
            }
        }
        while (items.isNotEmpty() && items[items.size - 1] is Item.Pause) {
            items.removeAt(items.size - 1)
        }
        return items
    }

    // ---------------------------------------------------------------- découpage en phrases

    private fun isTerminator(c: Char): Boolean =
        c == '.' || c == '!' || c == '?' || c == '\u2026' || c == '\u061F'

    private fun isCloser(c: Char): Boolean =
        c == '"' || c == '\'' || c == ')' || c == ']' || c == '\u00BB' || c == '\u201D' || c == '\u2019'

    private fun isBoundary(t: String, i: Int): Boolean {
        val c = t[i]
        val next = if (i + 1 < t.length) t[i + 1] else ' '
        val prev = if (i > 0) t[i - 1] else ' '
        val nextOk = next.isWhitespace() || isCloser(next) || isTerminator(next)
        if (!nextOk) return false
        if (c == '.') {
            if (prev.isDigit() && next.isDigit()) return false
            var s = i
            while (s > 0 && t[s - 1].isLetter()) s--
            val word = t.substring(s, i).lowercase()
            if (word in ABBREVIATIONS) return false
        }
        return true
    }

    private fun split(text: String): List<Sent> {
        val out = ArrayList<Sent>()
        val n = text.length
        var start = 0
        var i = 0
        while (i < n) {
            val c = text[i]
            if (c == '\n' || c == '\r') {
                var j = i
                var newlines = 0
                while (j < n && (text[j] == '\n' || text[j] == '\r' || text[j] == ' ' || text[j] == '\t')) {
                    if (text[j] == '\n') newlines++
                    j++
                }
                out.add(Sent(start, i, if (newlines >= 2) 3 else 2, '\n'))
                start = j
                i = j
                continue
            }
            if (isTerminator(c) && isBoundary(text, i)) {
                var j = i + 1
                while (j < n && (isTerminator(text[j]) || isCloser(text[j]))) j++
                out.add(Sent(start, j, 1, c))
                while (j < n && (text[j] == ' ' || text[j] == '\t')) j++
                start = j
                i = j
                continue
            }
            i++
        }
        if (start < n) out.add(Sent(start, n, 0, ' '))
        return out
    }

    // ---------------------------------------------------------------- nettoyage

    private fun clean(raw: String, cfg: FilterConfig): String {
        val cps = raw.toCodePointList()
        val sb = StringBuilder(raw.length)
        for (idx in cps.indices) {
            val cp = cps[idx]
            val prev = if (idx > 0) cps[idx - 1] else 32
            val next = if (idx + 1 < cps.size) cps[idx + 1] else 32
            when {
                cp == 0x200D || cp == 0xFE0F || cp == 0x200B -> { /* ignoré */ }
                cp == 9 -> sb.append(' ')
                // émojis et pictogrammes : jamais lus
                Character.getType(cp) == Character.OTHER_SYMBOL.toInt() -> sb.append(' ')
                cp in cfg.symbolsOff -> {
                    // apostrophe ou trait d'union à l'intérieur d'un mot : conservé (l'homme, peut-être)
                    val inWord = (cp == '\''.code || cp == 0x2019 || cp == '-'.code) &&
                        Character.isLetterOrDigit(prev) && Character.isLetterOrDigit(next)
                    if (inWord) sb.appendCodePoint(cp) else sb.append(' ')
                }
                cp in cfg.punctOff -> {
                    val decimal = (cp == '.'.code || cp == ','.code || cp == ':'.code) &&
                        Character.isDigit(prev) && Character.isDigit(next)
                    when {
                        decimal -> sb.appendCodePoint(cp)
                        cfg.punctMode == PunctMode.REMOVE -> sb.append(' ')
                        // ? et ! gardent l'intonation de la phrase, sans jamais être prononcés
                        cp == '?'.code || cp == '!'.code || cp == 0x061F -> sb.appendCodePoint(cp)
                        // virgule, point-virgule, deux-points : courte pause naturelle du moteur
                        cp == ','.code || cp == ';'.code || cp == ':'.code || cp == 0x060C || cp == 0x061B -> sb.append(',')
                        // point, points de suspension : la pause est ajoutée entre les phrases
                        else -> sb.append(' ')
                    }
                }
                else -> sb.appendCodePoint(cp)
            }
        }
        var s = sb.toString()
        s = s.replace(Regex("\\s+"), " ")
        s = s.replace(Regex("(\\s*,\\s*){2,}"), ", ")
        s = s.replace(Regex("\\s+([,?!\u061F])"), "\$1")
        return s.trim().trimEnd(',', ' ').trimStart(',', ' ')
    }

    // ---------------------------------------------------------------- segments trop longs

    private fun chunk(t: String, max: Int = 700): List<String> {
        if (t.length <= max) return listOf(t)
        val out = ArrayList<String>()
        var s = 0
        while (s < t.length) {
            var e = minOf(s + max, t.length)
            if (e < t.length) {
                val sp = t.lastIndexOf(' ', e)
                if (sp > s + max / 2) e = sp
            }
            val part = t.substring(s, e).trim()
            if (part.isNotEmpty()) out.add(part)
            s = e
        }
        return out
    }
}
