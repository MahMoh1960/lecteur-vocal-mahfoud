package ma.lecteurvocal

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener

/**
 * Enveloppe unique autour de TextToSpeech, partagée par le lecteur et l'enregistreur.
 * Les fins d'énoncés sont renvoyées sur le thread principal.
 */
class TtsHub(context: Context, private val onReady: (Boolean) -> Unit) {

    lateinit var tts: TextToSpeech
        private set

    var ready: Boolean = false
        private set

    private val main = Handler(Looper.getMainLooper())

    /** Appelé sur le thread principal : (identifiant de l'énoncé, succès). */
    var onUtteranceEnd: ((String, Boolean) -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        post(utteranceId, true)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        post(utteranceId, false)
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        post(utteranceId, false)
                    }
                })
            }
            main.post { onReady(ready) }
        }
    }

    private fun post(id: String?, ok: Boolean) {
        if (id == null) return
        main.post { onUtteranceEnd?.invoke(id, ok) }
    }

    fun shutdown() {
        try {
            tts.stop()
            tts.shutdown()
        } catch (e: Exception) {
            // rien à faire
        }
    }
}
