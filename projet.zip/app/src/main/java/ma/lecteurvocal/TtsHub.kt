package ma.lecteurvocal

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice

/**
 * Enveloppe unique autour de TextToSpeech, partagée par le lecteur et l'enregistreur.
 * Les fins d'énoncés sont renvoyées sur le thread principal.
 */
class TtsHub(context: Context, private val prefs: Prefs, private val onReady: (Boolean) -> Unit) {

    lateinit var tts: TextToSpeech
        private set

    var ready: Boolean = false
        private set

    private val main = Handler(Looper.getMainLooper())

    /** Appelé sur le thread principal : (identifiant de l'énoncé, succès). */
    var onUtteranceEnd: ((String, Boolean) -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        post(utteranceId, true)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        post(utteranceId, false)
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        post(utteranceId, false)
                    }
                })
            }
            main.post { onReady(ready) }
        }
    }

    private fun post(id: String?, ok: Boolean) {
        if (id == null) return
        main.post { onUtteranceEnd?.invoke(id, ok) }
    }

    /** Voix installées pour une langue (triées par nom). */
    fun voicesFor(lang: Lang): List<Voice> {
        return try {
            val all = tts.voices ?: return emptyList()
            all.filter {
                it.locale.language == lang.locale.language &&
                    it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
            }.sortedBy { it.name }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Règle la langue et la voix choisie (féminine ou masculine) ; false si la langue est indisponible. */
    fun prepare(lang: Lang): Boolean = prepareWith(lang, prefs.voiceFor(lang, prefs.gender))

    fun prepareWith(lang: Lang, voiceName: String?): Boolean {
        val r = tts.setLanguage(lang.locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return false
        if (!voiceName.isNullOrEmpty()) {
            val v = voicesFor(lang).firstOrNull { it.name == voiceName }
            if (v != null) {
                try {
                    tts.setVoice(v)
                } catch (e: Exception) {
                    // on garde la voix par défaut de la langue
                }
            }
        }
        return true
    }

    fun shutdown() {
        try {
            tts.stop()
            tts.shutdown()
        } catch (e: Exception) {
            // rien à faire
        }
    }
}
